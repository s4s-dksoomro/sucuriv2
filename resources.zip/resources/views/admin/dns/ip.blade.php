@inject('request', 'Illuminate\Http\Request')
@extends('layouts.app')
@section('content')



<div class="row">
                <div class="col-xs-12">
                    <h2>Settings</h2>
                    <div class="panel panel-success">
                        <div class="panel-body">

                            
                            <h4>Details</h4>
                

        

                        </div>
                    </div>
                </div>
            </div>









@stop

@section('javascript') 
    
@endsection
